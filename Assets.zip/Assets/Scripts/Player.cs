using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float moveSpeed;
    public Rigidbody2D rb2d;
    Vector2 movement;
    public Animator animator;

    public Text TrashCounterText;
    public int TrashCounter;

    public bool canCollect;
    public GameObject trashObject;

    public Text energyText;
    public int energy;
    private float energyDecreaseTimer = 1f;
    private float currentEnergyDecreaseTimer;

    public bool isLevelEnd;
    public bool canMove;

    public GameObject losePanel;
    public GameObject nextLevelPanel;

    public bool canplayDieSound;

    public Text levelText;
    public int level;

    void Start()
    {
        level = PlayerPrefs.GetInt("level", 1);
        levelText.text = level.ToString();

        canplayDieSound = true;
        isLevelEnd = false;
        canCollect = false;
        canMove = true;

        TrashCounter = 0;
        TrashCounterText.text = TrashCounter.ToString();

        energy = 100; // 100
        energyText.text = energy.ToString();

        currentEnergyDecreaseTimer = energyDecreaseTimer;
    }


    void Update()
    {
        PlayerDead();

        if (canMove)//
        { 
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Collect();
        }
        }//
    }

    private void FixedUpdate()
    {
        SetAnimationState();

        if (canMove)//
        {
        rb2d.MovePosition(rb2d.position + movement * moveSpeed * Time.fixedDeltaTime);

        if (movement.x < 0)
        {
            transform.rotation = Quaternion.Euler(0, -180, 0);
        }
        else if (movement.x > 0)
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }

        // Enerji azaltma i�lemi
        if (movement.x != 0 || movement.y != 0)
        {
            currentEnergyDecreaseTimer -= Time.deltaTime;
            if (currentEnergyDecreaseTimer <= 0)
            {
                energy = energy - 5;
                energyText.text = energy.ToString();
                currentEnergyDecreaseTimer = energyDecreaseTimer;
            }
        }
        }//
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Trash"))
        {
            canCollect = true;
            trashObject = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision) // Oyuncu ��p� toplamadan uzakla��rsa spaceye bast���nda toplamas�n diye
    {
        if (collision.CompareTag("Trash"))
        {
            canCollect = false;
            trashObject = null;
        }
    }

    public void Collect()
    {
        if (trashObject != null && canCollect)
        {
            SoundManager.Instance.PlaySFX("collect");

            Destroy(trashObject);
            TrashCounter++;
            TrashCounterText.text = TrashCounter.ToString();

            energy = energy + 20;
            energyText.text = energy.ToString();

            LevelEnd();
        }
        canCollect = false; 
    }

    public void LevelEnd()
    {
        int levelx = PlayerPrefs.GetInt("level", 1);
        int howManyTrashesNeeded = (levelx * 5) + 15;

        if (TrashCounter == howManyTrashesNeeded)
        {
            isLevelEnd = true;

            nextLevelPanel.SetActive(true);
        }
    }

    public void PlayerDead()
    {
        if(energy == 0)
        {
            if (canplayDieSound)
            {
                SoundManager.Instance.PlaySFX("die");
            }

            canplayDieSound = false;
            canMove = false;

            StartCoroutine("WaitForEnd");
        }
    }

    private IEnumerator WaitForEnd()
    {
        yield return new WaitForSeconds(1.25f);
        losePanel.SetActive(true);
    }
 
    public void SetAnimationState()
    {
        if (canMove)
        {
            if (movement.x < 0 || movement.x > 0 || movement.y < 0 || movement.y > 0)
            {
                animator.SetBool("isRunning", true);
            }
            else
            {
                animator.SetBool("isRunning", false);
            }
        }

        if(energy == 0)
        {
            animator.SetBool("isDead", true);
        }
    }
}
