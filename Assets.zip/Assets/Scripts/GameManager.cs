using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    void Start()
    {

    }

    public void StartGame()
    {
        PlayerPrefs.DeleteAll();
        SceneManager.LoadScene("0");
    }

    public void TryAgain()
    {
        SoundManager.Instance.PlaySFX("btn");

        PlayerPrefs.DeleteAll();
        SceneManager.LoadScene("0");
    }

    public void NextLevel()
    {
        SoundManager.Instance.PlaySFX("btn");

        PlayerPrefs.SetInt("level", PlayerPrefs.GetInt("level", 1) + 1);
        SceneManager.LoadScene("0");
    }
}
