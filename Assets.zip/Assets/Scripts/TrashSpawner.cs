using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrashSpawner : MonoBehaviour
{
    public GameObject[] trashPrefabs;
    public Vector2 spawnAreaCenter;
    public Vector2 spawnAreaSize;
    public int numberOfTrashToSpawn;

    private List<Vector2> spawnedPositions = new List<Vector2>();

    public int level;

    void Start()
    {
        level = PlayerPrefs.GetInt("level", 1);
        numberOfTrashToSpawn = (level * 5) + 15;
        SpawnTrash();
    }

    void SpawnTrash()
    {
        GameObject trashesObject = GameObject.Find("Trashes");
        if (trashesObject == null)
        {
            Debug.LogError("Trashes object not found!");
            return;
        }

        for (int i = 0; i < numberOfTrashToSpawn; i++)
        {
            Vector2 randomPosition = GetRandomSpawnPosition();
            while (IsOverlapping(randomPosition))
            {
                randomPosition = GetRandomSpawnPosition();
            }

            int randomTrashIndex = Random.Range(0, trashPrefabs.Length);
            GameObject newTrash = Instantiate(trashPrefabs[randomTrashIndex], randomPosition, Quaternion.identity);
            newTrash.transform.parent = trashesObject.transform;
            spawnedPositions.Add(newTrash.transform.position);
        }
    }

    Vector2 GetRandomSpawnPosition()
    {
        float randomX = Random.Range(spawnAreaCenter.x - spawnAreaSize.x / 2, spawnAreaCenter.x + spawnAreaSize.x / 2);
        float randomY = Random.Range(spawnAreaCenter.y - spawnAreaSize.y / 2, spawnAreaCenter.y + spawnAreaSize.y / 2);
        return new Vector2(randomX, randomY);
    }

    bool IsOverlapping(Vector2 position)
    {
        foreach (Vector2 spawnedPosition in spawnedPositions)
        {
            if (Vector2.Distance(position, spawnedPosition) < 1.0f) // �ak��ma kontrol� i�in 1 birimlik mesafe kontrol� yap�l�yor
            {
                return true;
            }
        }
        return false;
    }
}
